CREATE DATABASE InfyTraders
GO

DROP TABLE Users;
Drop table Shares;
Drop TABLE Shareholder;

CREATE TABLE Roles(
	[RoleId] INTEGER CONSTRAINT pk_RoleId PRIMARY KEY,
	RoleName VARCHAR(15) NOT NULL
)
CREATE TABLE Users
(
	[EmailId] VARCHAR(50) CONSTRAINT pk_EmailId PRIMARY KEY,
	[UserPassword] VARCHAR(15) NOT NULL,
	[Contact no] VARCHAR(10) NOT NULL,
	[Gender] CHAR CONSTRAINT chk_Gender CHECK(Gender='F' OR Gender='M') NOT NULL,
	[DateOfBirth] DATE CONSTRAINT chk_DateOfBirth CHECK(DateOfBirth<GETDATE()) NOT NULL,
	[Address] VARCHAR(200) NOT NULL,
	[AadharNo] VARCHAR(12) NOT NULL,
	[PanNo] VARCHAR(10) NOT NULL,
	[RoleId] INTEGER NOT NULL CONSTRAINT fk_roleId REFERENCES Roles(RoleId)
)
GO
alter table users drop DF__Users__Status__5AEE82B9
Alter table Users DROP COLUMN [Status]
alter table users add [Status] INT not null Default 0
CREATE TABLE Shares
(
	[ShareName] VARCHAR(200) CONSTRAINT pk_Share PRIMARY KEY NOT NULL,
	[BidQuantity] FLOAT NOT NULL,
	[BidPrice] FLOAT NOT NULL,
	[OfferPrice] FLOAT NOT NULL,
	[OfferQuantity] FLOAT NOT NULL,
	[PercentChange] FLOAT NOT NULL,  
)
GO
CREATE TABLE Shareholder
(
	[ShareHolderShareId] INTEGER CONSTRAINT pk_ShareHolderId2 PRIMARY KEY IDENTITY(1,1),
	[EmailId] VARCHAR(50) NOT NULL constraint fk_emailid REFERENCES Users([EmailId]),
	[ShareName] VARCHAR(200) NOT NULL constraint fk_sharename REFERENCES Shares([ShareName]),
	[Quantity] FLOAT NOT NULL,
)
GO

Insert INTO Roles Values(1,'Admin')
Insert INTO Roles Values(2,'User')
--insertion scripts for Users
INSERT INTO Users VALUES('Franken@gmail.com','BSBEV@1234','8954433553','F','1976-08-26','Fauntleroy Circus','543646435637','HG32HKF673',2)
INSERT INTO Users VALUES('tanisha@gmail.com','BSBEV@1235','8101254789','F','1996-08-26','Sikkim','543646435638','FG32HJF673',1)
INSERT INTO Users VALUES('subhantika@gmail.com','BSBEV@1134','8154433553','F','1995-08-26','Siliguri','543646435639','HG72HJF673',2)
INSERT INTO Users VALUES('sunny@gmail.com','BSBE@1234','8954433573','M','1995-08-27','Patna','543646435634','HG32HJF678',2)
INSERT INTO Users VALUES('kaustubh@gmail.com','BSBEV@124','8954433554','M','1976-08-28','Kolkata','543646435635','JG32HJF673',2)
INSERT INTO Users VALUES('shubham@gmail.com','BSBEV@1239','8954433552','M','1976-09-26','Ranchi','543646435636','HG35HJF673',1)
INSERT INTO Users VALUES('archana@gmail.com','BSBEV@1214','8974433553','F','1976-07-26','Pakyong','543646435631','HP32HJF673',2)
INSERT INTO Users VALUES('sayantan@gmail.com','BSBEV@1314','8955433553','M','1976-06-26','Hyderabad','543646435683','HG32HJF973',2)
INSERT INTO Users VALUES('apoorva@gmail.com','BSBEV@1258','8954437553','F','1976-05-26','Ranchi','543646438633','HG32HJP673',2)
INSERT INTO Users VALUES('abhishek@gmail.com','BSBEV@14','8954433053','M','1976-04-26','Delhi','543846435633','HG32HJZ673',2)

Insert Into Shares VALUES('Bharti Airtel',180,355.95,356.00,100,0)
Insert Into Shares VALUES('Britannia',150,300.95,302.00,10,0)
Insert Into Shares VALUES('ZEEL',112,323.95,325.00,18,0)
Insert Into Shares VALUES('HDFC BANK',178,35.95,36.00,140,0)
Insert Into Shares VALUES('MARUTI',140,555.95,556.00,160,0)
Insert Into Shares VALUES('CIPLA LIMITED',156,155.95,156.00,78,0)
Insert Into Shares VALUES('CAMEX LTD.',10,31.95,35.00,80,0)
Insert Into Shares VALUES('CANARA BANK',543,5.95,6.00,140,0)
Insert Into Shares VALUES('Palco LTD.',13,5.95,6.40,87,0)
Insert Into Shares VALUES('SAL STEEL LTD.',184,315.95,316.00,110,0)


GO

Insert Into Shareholder VALUES('Franken@gmail.com','Bharti Airtel',78)
Insert Into Shareholder VALUES('sunny@gmail.com','HDFC BANK',54)
Insert Into Shareholder VALUES('apoorva@gmail.com','MARUTI',89)

