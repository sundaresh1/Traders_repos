﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Infosys.DataAccessLayer.Models;
using System.Linq;

namespace Infosys.DataAccessLayer
{
   public class InfyTradersRepository
    {
        private readonly InfyTradersContext _context;
        public InfyTradersRepository(InfyTradersContext context)
        {
            _context = context;
        }
        public List<Users> GetAllUsers()
        {
            
            return _context.Users.ToList();

        }
        public List<Shares> GetAllShares()
        {

            return _context.Shares.ToList();

        }
        public List<Shareholder> GetAllShareholder(String id)
        {

            return (from d in _context.Shareholder  select d).ToList();
            

            }
   

        public byte? ValidateCredentials(string userId, string password)
        {
            byte? roleId = 0;
            try
            {
                Users user = _context.Users.Find(userId);
               
                if (user.UserPassword == password)
                {
                    roleId = 1;
                }
                return roleId;
            }
            catch
            {
                return roleId;
            }          
        }
        public Shares GetShare(string shares)
        {
            Shares share = null;
            try
            {
                share = (from d in _context.Shares where d.ShareName == shares select d).First();
                return share;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public Shareholder GetShareholder(string id,string name)
        {
            Shareholder share = null;
            try
            {
                share = (from d in _context.Shareholder where d.ShareName == name && d.EmailId==id select d).First();
                return share;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public bool UpdateProduct(Models.Shares product,string data)
        {
            try
            {
                Shareholder share = (from d in _context.Shareholder where d.ShareName == product.ShareName && d.EmailId == "abhishek@gmail.com" select d).First();
                if (share != null)
                    share.Quantity += product.BidQuantity;
                _context.Shareholder.Update(share);

                Shares dbProduct = _context.Shares.Find(product.ShareName);
                dbProduct.BidQuantity += product.BidQuantity;
                _context.Shares.Update(dbProduct);
                _context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public bool UpdateProduct2(Models.Shareholder product)
        {
            try
            {
                Shares share = (from d in _context.Shares where d.ShareName == product.ShareName select d).First();
                share.OfferQuantity += product.Quantity;
                _context.Shares.Update(share);

                Shareholder dbProduct = (from d in _context.Shareholder where d.ShareName == product.ShareName && d.EmailId==product.EmailId select d).First();
                dbProduct.Quantity -= product.Quantity;
                _context.Shareholder.Update(dbProduct);
                _context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public bool Sell(Shares catObj)
        {
            try
            {
                var catObjFromDB = _context.Shares.Where(x => x.ShareName == catObj.ShareName).Select(x => x).FirstOrDefault();
                catObjFromDB.BidQuantity = catObj.BidQuantity;
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
